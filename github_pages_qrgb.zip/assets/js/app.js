// JavaScript para el Generador de Códigos QR

document.addEventListener('DOMContentLoaded', function() {
    // Elementos del DOM
    const generateBtn = document.getElementById('generate-btn');
    const downloadBtn = document.getElementById('download-btn');
    const qrcodeContainer = document.getElementById('qrcode-container');
    const textInput = document.getElementById('text-input');
    const qrColor = document.getElementById('qr-color');
    const bgColor = document.getElementById('bg-color');
    
    // Variable para almacenar la imagen QR generada
    let qrImage = null;
    
    // Event listeners
    generateBtn.addEventListener('click', generateQR);
    downloadBtn.addEventListener('click', downloadQR);
    
    // Función para generar el código QR
    function generateQR() {
        // Obtener valores de los inputs
        const text = textInput.value || 'https://github.com/ibarfedericoanderson';
        const darkColor = qrColor.value;
        const lightColor = bgColor.value;
        
        // Limpiar el contenedor
        qrcodeContainer.innerHTML = '';
        
        // Generar el nuevo QR con la librería QRCode.js
        QRCode.toCanvas(qrcodeContainer, text, {
            width: 240,
            margin: 1,
            color: {
                dark: darkColor,
                light: lightColor
            }
        }, function(error) {
            if (error) {
                console.error(error);
                qrcodeContainer.innerHTML = '<p class="text-danger">Error al generar el código QR</p>';
                downloadBtn.disabled = true;
            } else {
                downloadBtn.disabled = false;
                qrImage = qrcodeContainer.querySelector('canvas');
                
                // Efecto visual al generar correctamente
                qrImage.classList.add('shadow');
            }
        });
    }
    
    // Función para descargar el código QR
    function downloadQR() {
        if (!qrImage) return;
        
        const link = document.createElement('a');
        link.download = 'codigo-qr-personalizado.png';
        link.href = qrImage.toDataURL('image/png');
        link.click();
        
        // Mostrar mensaje de éxito
        const successMsg = document.createElement('div');
        successMsg.className = 'alert alert-success mt-2';
        successMsg.textContent = '¡Código QR descargado correctamente!';
        qrcodeContainer.appendChild(successMsg);
        
        // Eliminar mensaje después de 3 segundos
        setTimeout(() => {
            successMsg.remove();
        }, 3000);
    }
    
    // Generar un QR inicial automáticamente
    generateQR();
    
    // Información adicional sobre el autor
    console.log("Generador de Códigos QR desarrollado por Ibar Federico Anderson");
    console.log("GitHub: https://github.com/ibarfedericoanderson");
});