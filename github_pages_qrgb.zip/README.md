# Generador de Códigos QR Personalizados - Versión Web

![Generador de Códigos QR](https://img.shields.io/badge/QR-Generator-blue)
![GitHub](https://img.shields.io/badge/GitHub-Pages-green)

Versión web simplificada del proyecto QRGB, un generador de códigos QR con opciones de personalización de color.

## Características

- Genera códigos QR personalizados con colores ajustables
- Interfaz web sencilla e intuitiva
- Permite guardar los códigos QR generados como imágenes PNG
- Versión ligera para GitHub Pages

## Autor

**Ibar Federico Anderson, Ph.D.**

- [Perfil de GitHub](https://github.com/ibarfedericoanderson)
- [Repositorio del proyecto completo](https://github.com/ibarfedericoanderson/ScriptPythonAppQRGB)

## Tecnologías utilizadas

- HTML, CSS y JavaScript
- Bootstrap 5 para el diseño responsive
- [QRCode.js](https://github.com/davidshimjs/qrcodejs) para la generación de códigos QR

## Sobre este proyecto

Este generador de códigos QR es una versión web simplificada del proyecto QRGB, desarrollado por Ibar Federico Anderson con asistencia de la IA de Replit (Claude Sonnet 3.5).

El proyecto original incluye:
- Una aplicación de escritorio desarrollada con Kivy y Python
- Versión Streamlit para una experiencia web interactiva
- Capacidad para codificar datos diferentes en cada capa RGB

## Enlaces relacionados

- [Sitio web informativo](https://federicoandersonar.wixsite.com/app-qrgb)
- [Versión web en Streamlit Cloud](https://appqrgbpythonappapp-kz8zenrno2ybehz4zgkccc.streamlit.app/)
- [Script Python en GitHub](https://github.com/ibarfedericoanderson/ScriptPythonAppQRGB/blob/main/QRGB.py)

## Desarrollo

Este proyecto fue desarrollado como una versión web simplificada para ser alojada en GitHub Pages, permitiendo a los usuarios generar códigos QR personalizados directamente desde el navegador.

---

Desarrollado con ❤️ por Ibar Federico Anderson con asistencia de la IA de Replit