"""
Script para ejecutar la versión local de la aplicación web de QRGB en VSCode.

Este script configura un entorno Flask básico que permite ejecutar la aplicación
web informativa sobre herramientas de IA en Replit y también incluye el código
de la aplicación QRGB para su visualización y descarga.

Instrucciones de uso:
1. Asegúrate de tener Python instalado (3.7 o superior)
2. Instala las dependencias necesarias:
   pip install flask pillow qrcode
3. Coloca este script en una carpeta vacía donde quieras crear el proyecto
4. Ejecuta este script: python launch_vscode_local.py
5. Abre http://localhost:5000 en tu navegador
"""

import os
import shutil
import sys
import subprocess

# Colores para mensajes en la terminal
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

def print_header(msg):
    print(f"\n{Colors.HEADER}{Colors.BOLD}==== {msg} ===={Colors.ENDC}")

def print_step(msg):
    print(f"{Colors.BLUE}→ {msg}{Colors.ENDC}")

def print_success(msg):
    print(f"{Colors.GREEN}✓ {msg}{Colors.ENDC}")

def print_warning(msg):
    print(f"{Colors.WARNING}⚠ {msg}{Colors.ENDC}")

def print_error(msg):
    print(f"{Colors.FAIL}✗ {msg}{Colors.ENDC}")

def create_directory(path):
    if not os.path.exists(path):
        os.makedirs(path)
        print_step(f"Creando directorio {path}")

def verify_python_version():
    print_header("Verificando versión de Python")
    
    major = sys.version_info.major
    minor = sys.version_info.minor
    
    if major < 3 or (major == 3 and minor < 7):
        print_error(f"Se requiere Python 3.7 o superior. Versión actual: {major}.{minor}")
        print_warning("Por favor, actualiza tu versión de Python e intenta nuevamente.")
        sys.exit(1)
    
    print_success(f"Versión de Python OK: {major}.{minor}")

def install_dependencies():
    print_header("Instalando dependencias")
    
    dependencies = ["flask", "pillow", "qrcode"]
    
    for dep in dependencies:
        print_step(f"Instalando {dep}...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", dep])
            print_success(f"{dep} instalado correctamente")
        except subprocess.CalledProcessError:
            print_error(f"Error al instalar {dep}")
            print_warning("Intenta instalar las dependencias manualmente con: pip install flask pillow qrcode")
            sys.exit(1)

def create_project_structure():
    print_header("Creando estructura del proyecto")
    
    # Directorios principales
    create_directory("static")
    create_directory("static/css")
    create_directory("static/js")
    create_directory("templates")
    
    print_success("Estructura de directorios creada")

def create_app_py():
    print_step("Creando app.py...")
    
    with open("app.py", "w", encoding="utf-8") as f:
        f.write("""import os
import logging
from flask import Flask, render_template, send_from_directory

# Configurar logging para facilitar la depuración
logging.basicConfig(level=logging.DEBUG)

# Crear la aplicación Flask
app = Flask(__name__)
app.secret_key = "clave_secreta_local_para_desarrollo"

# Rutas de la aplicación
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/claude')
def claude():
    return render_template('claude.html')

@app.route('/asistente')
def asistente():
    return render_template('asistente.html')

@app.route('/comparacion')
def comparacion():
    return render_template('comparacion.html')

@app.route('/recursos')
def recursos():
    return render_template('recursos.html')

@app.route('/codigo')
def codigo():
    # Leer el contenido del archivo Python para mostrarlo en la página
    with open('static/QRGB.py', 'r', encoding='utf-8') as file:
        codigo_python = file.read()
    return render_template('codigo.html', codigo_python=codigo_python)

@app.route('/descargar/streamlit')
def descargar_streamlit():
    return send_from_directory('static', 'app_qrgb_streamlit.py')

# Si el archivo se ejecuta directamente
if __name__ == "__main__":
    app.run(host="localhost", port=5000, debug=True)
""")
    
    print_success("Archivo app.py creado")

def create_qrgb_py():
    print_step("Descargando QRGB.py...")
    
    # URL del código fuente en GitHub
    github_url = "https://raw.githubusercontent.com/ibarfedericoanderson/ScriptPythonAppQRGB/main/QRGB.py"
    
    try:
        import urllib.request
        response = urllib.request.urlopen(github_url)
        code = response.read().decode('utf-8')
        
        with open("static/QRGB.py", "w", encoding="utf-8") as f:
            f.write(code)
        
        print_success("QRGB.py descargado y guardado")
    except Exception as e:
        print_error(f"Error al descargar QRGB.py: {e}")
        print_warning("Crea manualmente el archivo static/QRGB.py descargándolo desde GitHub")

def create_streamlit_app():
    print_step("Creando versión Streamlit...")
    
    with open("static/app_qrgb_streamlit.py", "w", encoding="utf-8") as f:
        f.write("""import streamlit as st
from PIL import Image
import qrcode
import io
import base64

def generar_qr(texto, color_fondo, color_qr):
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(texto)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color=color_qr, back_color=color_fondo)
    return img

def main():
    st.title("Generador de Códigos QR Personalizados")
    st.write("Desarrollado por Ibar Federico Anderson con asistencia de IA")
    
    # Entrada de texto para el código QR
    texto_qr = st.text_input("Introduce el texto o URL para el código QR:", "https://github.com/ibarfedericoanderson/ScriptPythonAppQRGB")
    
    # Selección de colores
    col1, col2 = st.columns(2)
    with col1:
        color_qr = st.color_picker("Color del código QR:", "#000000")
    with col2:
        color_fondo = st.color_picker("Color de fondo:", "#FFFFFF")
    
    # Botón para generar el QR
    if st.button("Generar código QR"):
        if texto_qr:
            qr_img = generar_qr(texto_qr, color_fondo, color_qr)
            
            # Mostrar la imagen
            st.image(qr_img, caption="Tu código QR personalizado")
            
            # Opción para descargar
            buf = io.BytesIO()
            qr_img.save(buf, format="PNG")
            byte_im = buf.getvalue()
            btn = st.download_button(
                label="Descargar código QR",
                data=byte_im,
                file_name="codigo_qr.png",
                mime="image/png"
            )
        else:
            st.error("Por favor, introduce algún texto para generar el código QR")
    
    st.markdown("---")
    st.markdown("**Proyecto Open Source** | [GitHub](https://github.com/ibarfedericoanderson/ScriptPythonAppQRGB) | [App Web](https://appqrgbpythonappapp-kz8zenrno2ybehz4zgkccc.streamlit.app/)")

if __name__ == "__main__":
    main()""")
    
    print_success("Archivo app_qrgb_streamlit.py creado")

def create_templates():
    print_step("Creando plantillas HTML...")
    
    # base.html
    with open("templates/base.html", "w", encoding="utf-8") as f:
        f.write("""<!DOCTYPE html>
<html lang="es" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}IA en Replit{% endblock %}</title>
    <!-- Bootstrap 5 desde CDN con tema oscuro -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome para iconos -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Estilos personalizados -->
    <link rel="stylesheet" href="{{ url_for('static', filename='css/styles.css') }}">
    {% block extra_css %}{% endblock %}
    <style>
        /* Estilos para tema oscuro */
        :root {
            --bs-body-bg: #212529;
            --bs-body-color: #f8f9fa;
        }
        body {
            background-color: var(--bs-body-bg);
            color: var(--bs-body-color);
        }
        .navbar {
            background-color: #2c3036 !important;
        }
        .card {
            background-color: #2c3036;
        }
        .accordion-button, .accordion-body {
            background-color: #2c3036;
            color: var(--bs-body-color);
        }
        .list-group-item {
            background-color: transparent;
            color: var(--bs-body-color);
        }
        .accordion-button:not(.collapsed) {
            background-color: #3a3f48;
        }
        footer {
            background-color: #2c3036 !important;
        }
        pre {
            background-color: #1a1d20;
            border-radius: 0.375rem;
            padding: 1rem;
        }
    </style>
</head>
<body>
    <!-- Barra de navegación -->
    <nav class="navbar navbar-expand-lg navbar-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="{{ url_for('index') }}">
                <i class="fas fa-robot me-2"></i>IA en Replit
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" 
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link {% if request.path == url_for('index') %}active{% endif %}" 
                           href="{{ url_for('index') }}">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {% if request.path == url_for('claude') %}active{% endif %}" 
                           href="{{ url_for('claude') }}">Claude Sonnet 3.5</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {% if request.path == url_for('asistente') %}active{% endif %}" 
                           href="{{ url_for('asistente') }}">Asistente de Replit</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {% if request.path == url_for('comparacion') %}active{% endif %}" 
                           href="{{ url_for('comparacion') }}">Comparación</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {% if request.path == url_for('recursos') %}active{% endif %}" 
                           href="{{ url_for('recursos') }}">Recursos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {% if request.path == url_for('codigo') %}active{% endif %}" 
                           href="{{ url_for('codigo') }}">Código QRGB</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Contenido principal -->
    <div class="container py-4">
        {% block content %}{% endblock %}
    </div>

    <!-- Pie de página -->
    <footer class="text-light py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5>Sobre esta página</h5>
                    <p>Información educativa sobre las herramientas de inteligencia artificial disponibles en Replit.</p>
                </div>
                <div class="col-md-3">
                    <h5>Enlaces</h5>
                    <ul class="list-unstyled">
                        <li><a href="https://replit.com" class="text-decoration-none text-info">Replit</a></li>
                        <li><a href="https://docs.replit.com" class="text-decoration-none text-info">Documentación</a></li>
                        <li><a href="https://blog.replit.com" class="text-decoration-none text-info">Blog de Replit</a></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <h5>Recursos</h5>
                    <ul class="list-unstyled">
                        <li><a href="https://replit.com/site/about" class="text-decoration-none text-info">Sobre Replit</a></li>
                        <li><a href="https://replit.com/site/teams-for-education" class="text-decoration-none text-info">Replit para educación</a></li>
                        <li><a href="https://replit.com/discord" class="text-decoration-none text-info">Discord</a></li>
                    </ul>
                </div>
            </div>
            <hr class="my-4">
            <div class="text-center">
                <p class="mb-0">© 2023 Sitio informativo sobre IA en Replit. No afiliado oficialmente con Replit.</p>
            </div>
        </div>
    </footer>

    <!-- JavaScript de Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- JavaScript personalizado -->
    <script src="{{ url_for('static', filename='js/main.js') }}"></script>
    {% block extra_js %}{% endblock %}
</body>
</html>""")

    # Crear página de código
    with open("templates/codigo.html", "w", encoding="utf-8") as f:
        f.write("""{% extends 'base.html' %}

{% block title %}Código QRGB - Python{% endblock %}

{% block content %}
<div class="row mb-5">
    <div class="col-lg-8 mx-auto text-center">
        <h1 class="display-5 fw-bold mb-4">Código de la App QRGB</h1>
        <p class="lead">Script Python desarrollado con asistencia de Claude Sonnet 3.5</p>
    </div>
</div>

<div class="row mb-4">
    <div class="col-lg-12">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <h2 class="card-title h4 mb-3">Descripción del proyecto</h2>
                <p>Esta aplicación, desarrollada por el Ph.D. Ibar Federico Anderson con asistencia de la IA de Replit, permite generar códigos QR con colores personalizados. Utiliza las bibliotecas Kivy para la interfaz gráfica, PIL para manipulación de imágenes y qrcode para la generación de códigos QR.</p>
                <p>El código está disponible como Open Source y puede ser adaptado para ejecutarse localmente en tu entorno de desarrollo.</p>
                
                <div class="alert alert-info">
                    <div class="d-flex">
                        <div class="flex-shrink-0">
                            <i class="fas fa-info-circle fa-2x me-3"></i>
                        </div>
                        <div>
                            <h4 class="alert-heading">Enlaces del proyecto</h4>
                            <p>Explora el proyecto completo en los siguientes enlaces:</p>
                            <ul>
                                <li><a href="https://federicoandersonar.wixsite.com/app-qrgb" class="text-decoration-none" target="_blank">Sitio web con información sobre la App</a></li>
                                <li><a href="https://github.com/ibarfedericoanderson/ScriptPythonAppQRGB" class="text-decoration-none" target="_blank">Repositorio en GitHub</a></li>
                                <li><a href="https://appqrgbpythonappapp-kz8zenrno2ybehz4zgkccc.streamlit.app/" class="text-decoration-none" target="_blank">Versión web en Streamlit Cloud</a></li>
                                <li><a href="{{ url_for('static', filename='QRGB.py') }}" class="text-decoration-none" download>Descargar script Python</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mb-5">
    <div class="col-lg-12">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <h2 class="card-title h4 mb-3">Código fuente</h2>
                <div class="bg-dark p-4 rounded">
                    <pre class="text-light" style="white-space: pre-wrap;"><code>{{ codigo_python }}</code></pre>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mb-5">
    <div class="col-lg-12">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <h2 class="card-title h4 mb-3">Instrucciones para ejecutar localmente en VSCode</h2>
                
                <div class="mb-4">
                    <h5>Requisitos previos</h5>
                    <ol>
                        <li>Tener Python instalado (versión 3.7 o superior)</li>
                        <li>Tener VSCode instalado con la extensión de Python</li>
                    </ol>
                </div>
                
                <div class="mb-4">
                    <h5>Instalación de dependencias</h5>
                    <p>Ejecuta el siguiente comando en la terminal de VSCode para instalar las bibliotecas necesarias:</p>
                    <div class="bg-dark p-3 rounded">
                        <pre class="text-light mb-0"><code>pip install kivy pillow qrcode opencv-python</code></pre>
                    </div>
                </div>
                
                <div class="mb-4">
                    <h5>Pasos para ejecutar</h5>
                    <ol>
                        <li>Descarga el archivo Python desde el enlace de descarga proporcionado</li>
                        <li>Abre VSCode y carga el archivo descargado</li>
                        <li>Abre una terminal en VSCode (Terminal > New Terminal)</li>
                        <li>Ejecuta el script con el comando: <code>python QRGB.py</code></li>
                    </ol>
                </div>
                
                <div class="alert alert-warning">
                    <div class="d-flex">
                        <div class="flex-shrink-0">
                            <i class="fas fa-exclamation-triangle fa-2x me-3"></i>
                        </div>
                        <div>
                            <h4 class="alert-heading">Nota importante</h4>
                            <p>Si encuentras problemas con la biblioteca Kivy, considera usar la versión web de la aplicación en Streamlit Cloud o consulta la documentación oficial de Kivy para solucionar problemas específicos de instalación según tu sistema operativo.</p>
                            <p class="mb-0">También puedes adaptar el código para usar otra biblioteca de interfaz gráfica como tkinter, que viene preinstalada con Python.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mb-5">
    <div class="col-lg-12">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <h2 class="card-title h4 mb-3">Versión Streamlit (más sencilla de ejecutar)</h2>
                <p>Si prefieres una versión más fácil de ejecutar localmente, puedes usar la versión Streamlit del código. Streamlit es una biblioteca de Python que permite crear aplicaciones web interactivas con menos código.</p>
                
                <div class="mb-4">
                    <h5>Instalación de Streamlit</h5>
                    <div class="bg-dark p-3 rounded">
                        <pre class="text-light mb-0"><code>pip install streamlit pillow qrcode</code></pre>
                    </div>
                </div>
                
                <div class="mb-4">
                    <h5>Código Streamlit</h5>
                    <p>Descarga la versión Streamlit desde el siguiente enlace:</p>
                    <a href="{{ url_for('descargar/streamlit') }}" class="btn btn-primary" download>Descargar app_qrgb_streamlit.py</a>
                </div>
                
                <div class="mb-4">
                    <h5>Ejecución de la versión Streamlit</h5>
                    <p>Para ejecutar esta versión, usa el siguiente comando en la terminal de VSCode:</p>
                    <div class="bg-dark p-3 rounded">
                        <pre class="text-light mb-0"><code>streamlit run app_qrgb_streamlit.py</code></pre>
                    </div>
                    <p class="mt-2">Esto abrirá automáticamente tu navegador web con la aplicación ejecutándose localmente.</p>
                </div>
            </div>
        </div>
    </div>
</div>
{% endblock %}""")

    # Crear página de inicio simple
    with open("templates/index.html", "w", encoding="utf-8") as f:
        f.write("""{% extends 'base.html' %}

{% block title %}IA en Replit - Herramientas de Inteligencia Artificial{% endblock %}

{% block content %}
<div class="row mb-5">
    <div class="col-lg-8 mx-auto text-center">
        <h1 class="display-4 fw-bold mb-4">Inteligencia Artificial en Replit</h1>
        <p class="lead mb-4">Explora las potentes herramientas de IA disponibles en la plataforma Replit para mejorar y acelerar tu desarrollo de software.</p>
        <div class="d-grid gap-2 d-md-flex justify-content-md-center">
            <a href="{{ url_for('claude') }}" class="btn btn-primary btn-lg px-4 me-md-2">Conoce Claude Sonnet 3.5</a>
            <a href="{{ url_for('asistente') }}" class="btn btn-outline-secondary btn-lg px-4">Asistente de Replit</a>
        </div>
    </div>
</div>

<div class="row mb-5">
    <div class="col-md-4 mb-4">
        <div class="card h-100 border-0 shadow-sm">
            <div class="card-body text-center">
                <i class="fas fa-brain fa-3x mb-3 text-primary"></i>
                <h3 class="card-title h4">Claude Sonnet 3.5</h3>
                <p class="card-text">Modelo de lenguaje avanzado de Anthropic, integrado en Replit para ayudarte con la generación de código, explicaciones y resolución de problemas.</p>
                <a href="{{ url_for('claude') }}" class="btn btn-outline-primary mt-auto">Más información</a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-4">
        <div class="card h-100 border-0 shadow-sm">
            <div class="card-body text-center">
                <i class="fas fa-robot fa-3x mb-3 text-success"></i>
                <h3 class="card-title h4">Asistente de Replit</h3>
                <p class="card-text">Asistente de IA integrado que proporciona ayuda contextual, completado de código y sugerencias mientras programas en tiempo real.</p>
                <a href="{{ url_for('asistente') }}" class="btn btn-outline-success mt-auto">Más información</a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-4">
        <div class="card h-100 border-0 shadow-sm">
            <div class="card-body text-center">
                <i class="fas fa-code fa-3x mb-3 text-warning"></i>
                <h3 class="card-title h4">Aplicación QRGB</h3>
                <p class="card-text">Ejemplo práctico de una aplicación desarrollada con asistencia de IA. Genera códigos QR personalizados con colores.</p>
                <a href="{{ url_for('codigo') }}" class="btn btn-outline-warning mt-auto">Ver código</a>
            </div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm mb-5">
    <div class="card-body p-4">
        <div class="row">
            <div class="col-lg-8">
                <h2 class="card-title h4 mb-3">¿Qué puedo hacer con estas herramientas?</h2>
                <p>Las herramientas de IA en Replit te permiten:</p>
                <ul>
                    <li>Generar código funcional a partir de descripciones</li>
                    <li>Depurar y corregir errores en tu código</li>
                    <li>Obtener explicaciones detalladas de conceptos de programación</li>
                    <li>Optimizar y refactorizar código existente</li>
                    <li>Recibir asistencia en tiempo real mientras programas</li>
                    <li>Crear aplicaciones completas con un mínimo de esfuerzo</li>
                </ul>
                <p>Explora el sitio para conocer más sobre cada herramienta y cómo puedes aprovecharlas en tus proyectos.</p>
            </div>
            <div class="col-lg-4 text-center">
                <img src="https://replit.com/public/images/ghostwriter/coding_copilot.svg" alt="Ilustración de IA ayudando a programar" class="img-fluid" style="max-height: 200px;">
            </div>
        </div>
    </div>
</div>
{% endblock %}""")

    # Crear páginas básicas para el resto de secciones
    for page in ["claude", "asistente", "comparacion", "recursos"]:
        with open(f"templates/{page}.html", "w", encoding="utf-8") as f:
            f.write(f"""{% extends 'base.html' %}

{{% block title %}}{page.capitalize()} - IA en Replit{{% endblock %}}

{{% block content %}}
<div class="row mb-5">
    <div class="col-lg-8 mx-auto text-center">
        <h1 class="display-5 fw-bold mb-4">{page.capitalize()}</h1>
        <p class="lead">Esta es una página de ejemplo para {page}.</p>
        <div class="alert alert-info">
            <p class="mb-0">Para ver el contenido completo, ejecuta la aplicación web original o visita la sección de <a href="{{ url_for('codigo') }}" class="alert-link">Código QRGB</a> para acceder al código de la aplicación.</p>
        </div>
    </div>
</div>
{{% endblock %}}""")
    
    print_success("Plantillas HTML creadas")

def create_css_js():
    print_step("Creando archivos CSS y JS...")
    
    with open("static/css/styles.css", "w", encoding="utf-8") as f:
        f.write("""/* Estilos personalizados */
body {
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

.container {
    flex: 1;
}

.card {
    transition: transform 0.3s ease;
}

.card:hover {
    transform: translateY(-5px);
}

.nav-link.active {
    font-weight: bold;
}
""")
    
    with open("static/js/main.js", "w", encoding="utf-8") as f:
        f.write("""// JavaScript personalizado
document.addEventListener('DOMContentLoaded', function() {
    // Agregar cualquier funcionalidad JavaScript aquí
    console.log('Aplicación web cargada correctamente');
});

// Función para resaltar elementos al hacer clic
function highlightElement(element) {
    element.classList.add('bg-primary', 'bg-opacity-25');
    setTimeout(() => {
        element.classList.remove('bg-primary', 'bg-opacity-25');
    }, 500);
}
""")
    
    print_success("Archivos CSS y JS creados")

def create_readme():
    print_step("Creando README.md...")
    
    with open("README.md", "w", encoding="utf-8") as f:
        f.write("""# Aplicación Web sobre IA en Replit con QRGB

Este proyecto es una aplicación web informativa desarrollada con Flask que explica las herramientas de IA disponibles en Replit e incluye un ejemplo real: la aplicación QRGB para generar códigos QR personalizados.

## Características

- Información sobre Claude Sonnet 3.5 y el Asistente de Replit
- Código fuente de la aplicación QRGB para generar códigos QR
- Versión Streamlit simplificada para fácil ejecución
- Instrucciones detalladas para ejecutar el código localmente

## Requisitos

- Python 3.7 o superior
- Flask
- Pillow (PIL)
- qrcode

## Instalación

1. Clona este repositorio o descárgalo como ZIP
2. Instala las dependencias:
   ```
   pip install flask pillow qrcode
   ```
3. Ejecuta la aplicación:
   ```
   python app.py
   ```
4. Abre http://localhost:5000 en tu navegador

## Ejecutar la aplicación QRGB

### Versión completa (Kivy)

1. Instala las dependencias adicionales:
   ```
   pip install kivy opencv-python
   ```
2. Descarga el archivo QRGB.py desde la página "Código QRGB"
3. Ejecuta:
   ```
   python QRGB.py
   ```

### Versión Streamlit (más sencilla)

1. Instala Streamlit:
   ```
   pip install streamlit
   ```
2. Descarga el archivo app_qrgb_streamlit.py desde la página "Código QRGB"
3. Ejecuta:
   ```
   streamlit run app_qrgb_streamlit.py
   ```

## Créditos

- Aplicación QRGB desarrollada por Ibar Federico Anderson con asistencia de IA
- Código original disponible en: https://github.com/ibarfedericoanderson/ScriptPythonAppQRGB
""")
    
    print_success("README.md creado")

def run_app():
    print_header("Iniciando aplicación web")
    print_step("La aplicación se iniciará en http://localhost:5000")
    
    try:
        if sys.platform == 'win32':
            os.system('start http://localhost:5000')
        elif sys.platform == 'darwin':
            os.system('open http://localhost:5000')
        else:
            os.system('xdg-open http://localhost:5000')
    except:
        print_warning("No se pudo abrir el navegador automáticamente. Por favor, abre http://localhost:5000 manualmente.")
    
    try:
        # Importar Flask al final para asegurarse de que está instalado
        from flask import Flask
        import subprocess
        subprocess.Popen([sys.executable, "app.py"])
        
        print_success("¡Aplicación iniciada correctamente!")
        print_header("Instrucciones adicionales")
        print("""
1. La aplicación web ahora está ejecutándose en http://localhost:5000
2. Explora las diferentes secciones para ver la información sobre IA en Replit
3. Ve a la sección "Código QRGB" para acceder al código de la aplicación de generación de QR
4. Descarga los archivos Python para ejecutarlos localmente

Para ejecutar la versión Streamlit (recomendada por su simplicidad):
1. Instala Streamlit: pip install streamlit
2. Descarga el archivo app_qrgb_streamlit.py desde la web
3. Ejecuta: streamlit run app_qrgb_streamlit.py

¡Disfruta explorando la aplicación!
""")
    except ImportError:
        print_error("Error al iniciar la aplicación. Asegúrate de haber instalado Flask correctamente.")
        print_warning("Intenta ejecutar manualmente: python app.py")

def main():
    print_header("CONFIGURACIÓN DE APLICACIÓN WEB LOCAL")
    print("Este script configurará un entorno local para ejecutar la aplicación web de QRGB en VSCode.")
    
    verify_python_version()
    install_dependencies()
    create_project_structure()
    create_app_py()
    create_qrgb_py()
    create_streamlit_app()
    create_templates()
    create_css_js()
    create_readme()
    run_app()

if __name__ == "__main__":
    main()