# Proyecto QRGB - Aplicación Web Informativa

Este proyecto contiene una aplicación web informativa sobre herramientas de IA en Replit y una aplicación para generar códigos QR personalizados.

## Instrucciones de Instalación y Uso

Hay dos formas de ejecutar este proyecto localmente:

### Opción 1: Usando el script automático (Recomendado)

1. Ejecuta el archivo `launch_vscode_local.py`:
   ```
   python launch_vscode_local.py
   ```
   Este script:
   - Verificará la versión de Python (necesitas Python 3.7+)
   - Instalará las dependencias necesarias (Flask, Pillow, QRcode)
   - Creará automáticamente toda la estructura del proyecto
   - Iniciará la aplicación web

2. Abre http://localhost:5000 en tu navegador

### Opción 2: Ejecutando manualmente

1. Instala las dependencias:
   ```
   pip install flask pillow qrcode
   ```

2. Ejecuta directamente la aplicación:
   ```
   python app.py
   ```

3. Abre http://localhost:5000 en tu navegador

## Versión Streamlit (Simplificada)

Para ejecutar solo la aplicación QRGB usando Streamlit:

1. Instala streamlit:
   ```
   pip install streamlit pillow qrcode
   ```

2. Ejecuta la versión Streamlit:
   ```
   streamlit run static/app_qrgb_streamlit.py
   ```

## Contenido del Proyecto

- `app.py`: Aplicación Flask principal
- `main.py`: Punto de entrada para la aplicación
- `static/QRGB.py`: Aplicación Kivy para generar códigos QR
- `static/app_qrgb_streamlit.py`: Versión Streamlit simplificada
- `templates/`: Plantillas HTML para la aplicación web

## Créditos

Desarrollado por Ibar Federico Anderson con asistencia de IA.
Repositorio original: https://github.com/ibarfedericoanderson/ScriptPythonAppQRGB